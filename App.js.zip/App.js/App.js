import React, {useState} from 'react';
import * as React from 'react';
import { Button, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { View,
         Text, 
         TextInput, 
         Button, 
         Picker, 
         TouchableOpacity,
        
} from 'react-native';


function HomeScreen({ navigation }) {

  const HomeScreen = ({ totalPages, lastBook, averagePages }) => {
  return (
    <View>
      <Text>Total Pages Read: {totalPages}</Text>
      <Text>Last Book Read: {lastBook.title}</Text>
      <Text>Average Pages: {averagePages}</Text>
    <Text>Title: {lastBook.title}</Text>
    <Text>Author: {lastBook.author}</Text>
    <Text>Genre: {lastBook.genre}</Text>
    <Text>Number of Pages: {lastBook.pages}</Text>
    </View>

  );
}; 
export default HomeScreen;
 
 
function BookApp() {
  
  const BookDetails = ({ addBook }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState('');
  const [pages, setPages] = useState('');

  const handleSubmit = () => {
    const book = { title, author, genre, pages: parseInt(pages) };
    addBook(book);
    setTitle('');
    setAuthor('');
    setGenre('');
    setPages('');
    
  };
  };

  return (
    <View>
      <Text>Title:</Text>
      <TextInput value={title} onChangeText={setTitle} />
      <Text>Author:</Text>
      <TextInput value={author} onChangeText={setAuthor} />
      <Text>Genre:</Text>
      <Picker selectedValue={genre} onValueChange={setGenre}>
       
      <Picker.Item label="Science" value="Science" />
        <Picker.Item label="Romance" value="Romance" />
        <Picker.Item label="Drama" value="Drama" />
        <Picker.Item label="Novel" value="Novel" /> 
        
      </Picker>
      <Text>Number of Pages:</Text>
      <TextInput value={pages} onChangeText={setPages} keyboardType="numeric" />
      <Button title="Add Your Book" onPress={handleSubmit} />
    </View>
  );
};

export default BookDetails;

export default function App() {
  const [books, setBooks] = useState([]);
  
  const addYourBook = (book) => {
    setBooks([...books, book]);
  };

  const lastBook = books[books.length - 1] || {};
  const totalPages = books.reduce((total, book) => total + book.pages, 0);
  const averagePages = books.length > 0 ? totalPages / books.length : 0;

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home">
          {() => <HomeScreen lastBook={lastBook} totalPages={totalPages} averagePages={averagePages} />}
        </Stack.Screen>
        <Stack.Screen name="AddYourBook">
          {() => <BookForm addYourBook={addYourBook} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const Stack = createNativeStackNavigator();

function MyStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="Book" component={BookDetails} />
      <Stack.Screen name="Async" component={AsyncStorage} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
 }; 


function App (){
  const [textValue, setTextValue] = useState('');
  const [getValue, setGetValue] = useState('');

  const fnSaveValue = () => {
    AsyncStorage.setItem('@data',textValue);
  };

  const fnGetValue = () => {
    AsyncStorage.getItem('@data').then(
                (value) => setGetValue(value)
    );
  };

  return(
      <View>
          <Text style={styles.title}>USING ASYNC STORAGE</Text>
          <TextInput
               style={styles.input}
               placeholder='What would you like to enter here?'
               onChangeText={setTextValue}
               value={textValue}
            />
          <TouchableOpacity onPress={fnSaveValue}>
            <View style={styles.button}>
                    <Text style={styles.buttonText}>SAVE VALUE</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={fnGetValue}>
          <View style={styles.button}>
                  <Text style={styles.buttonText}>RETRIEVE VALUE</Text>
            </View>
          </TouchableOpacity>
          <Text style={styles.output}>{getValue}</Text>
      </View>

  );

}

const styles = StyleSheet.create({
container:{
  flex: 1,
  padding: 8,
},
title:{
  fontSize: 28,
  fontWeight: 'bold',
  textAlign: 'center',
  paddingVertical: 20,
  color: 'orange',
},
output:{
  fontSize: 22,
  padding: 10,
  textAlign: 'center',
  borderWidth: 1,
  borderColor: 'black ',
},
button:{
  fontSize: 20,
  color: 'white',
  backgroundColor: 'green',
  padding: 8,
  marginTop: 30,
  width: '100%',
},
buttonText:{
  padding: 5,
  color: 'white',
  textAlign: 'center',
},
input:{
  textAlign: 'center',
  height: 38,
  width: '100%',
  borderWidth: 1,
  borderColor: 'pink',
},

});

export default App;

